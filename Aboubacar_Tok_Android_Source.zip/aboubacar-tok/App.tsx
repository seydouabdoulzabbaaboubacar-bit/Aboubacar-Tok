import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Platform,
  SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput,
  TouchableOpacity, View
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { VideoView, useVideoPlayer } from 'expo-video';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';
import { isConfigured, supabase } from './src/lib/supabase';

type Profile = { id: string; username: string; display_name: string; bio: string | null };
type Post = {
  id: string; user_id: string; caption: string; video_url: string;
  created_at: string; profiles?: Profile; likes_count?: number; liked?: boolean;
};

const pink = '#FE2C55';
const bg = '#09090B';
const panel = '#18181B';
const muted = '#A1A1AA';

function VideoCard({ post, userId, onLike, onComment, onFollow, following }: any) {
  const player = useVideoPlayer(post.video_url, p => { p.loop = true; });
  return (
    <View style={s.videoCard}>
      <VideoView player={player} style={s.video} contentFit="cover" nativeControls />
      <View style={s.videoOverlay}>
        <View style={{ flex: 1 }}>
          <Text style={s.whiteBold}>@{post.profiles?.username || 'membre'}</Text>
          <Text style={s.whiteText}>{post.caption}</Text>
          <Text style={s.smallMuted}>♫ Son original · Aboubacar Tok</Text>
        </View>
        <View style={s.actions}>
          <TouchableOpacity onPress={() => onLike(post)} style={s.action}>
            <Text style={[s.actionIcon, post.liked && { color: pink }]}>{post.liked ? '♥' : '♡'}</Text>
            <Text style={s.actionLabel}>{post.likes_count || 0}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => onComment(post)} style={s.action}>
            <Text style={s.actionIcon}>▢</Text><Text style={s.actionLabel}>Commenter</Text>
          </TouchableOpacity>
          {post.user_id !== userId && <TouchableOpacity onPress={() => onFollow(post)} style={s.action}>
            <Text style={s.actionIcon}>＋</Text><Text style={s.actionLabel}>{following ? 'Suivi' : 'Suivre'}</Text>
          </TouchableOpacity>}
          <TouchableOpacity onPress={() => Alert.alert('Signaler', 'Signaler cette vidéo ?', [
            { text: 'Annuler', style: 'cancel' },
            { text: 'Signaler', style: 'destructive', onPress: async () => {
              const { error } = await supabase.from('reports').insert({ reporter_id: userId, target_type: 'video', target_id: post.id, reason: 'Contenu à examiner' });
              Alert.alert(error ? 'Erreur' : 'Signalement envoyé', error?.message || 'Merci. Notre équipe pourra examiner ce contenu.');
            }}
          ])} style={s.action}>
            <Text style={s.actionIcon}>⚑</Text><Text style={s.actionLabel}>Signaler</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'feed'|'publish'|'messages'|'profile'>('feed');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [authMode, setAuthMode] = useState<'login'|'signup'>('signup');
  const [posts, setPosts] = useState<Post[]>([]);
  const [myProfile, setMyProfile] = useState<Profile|null>(null);
  const [caption, setCaption] = useState('');
  const [video, setVideo] = useState<ImagePicker.ImagePickerAsset|null>(null);
  const [commentText, setCommentText] = useState('');
  const [commentPost, setCommentPost] = useState<Post|null>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [chatUser, setChatUser] = useState('');
  const [chatText, setChatText] = useState('');
  const [messages, setMessages] = useState<any[]>([]);
  const [targetUsername, setTargetUsername] = useState('');
  const [editBio, setEditBio] = useState('');

  useEffect(() => {
    if (!isConfigured) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => { if (session?.user) loadAccount(); }, [session?.user?.id]);
  useEffect(() => { if (session?.user) loadFeed(); }, [session?.user?.id]);

  async function loadAccount() {
    const id = session.user.id;
    const { data } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle();
    if (data) { setMyProfile(data); setEditBio(data.bio || ''); }
  }

  async function loadFeed() {
    const { data, error } = await supabase.from('videos')
      .select('id,user_id,caption,video_url,created_at,profiles(id,username,display_name)')
      .eq('status', 'published').order('created_at', { ascending: false }).limit(40);
    if (error) { Alert.alert('Fil d’actualité', error.message); return; }
    const ids = (data || []).map((p:any) => p.id);
    let likeRows:any[] = [];
    if (ids.length) {
      const { data: likes } = await supabase.from('likes').select('video_id,user_id').in('video_id', ids);
      likeRows = likes || [];
    }
    setPosts((data || []).map((p:any) => ({
      ...p, likes_count: likeRows.filter(l => l.video_id === p.id).length,
      liked: likeRows.some(l => l.video_id === p.id && l.user_id === session.user.id)
    })));
  }

  async function authenticate() {
    if (!email.trim() || password.length < 8) return Alert.alert('Informations requises', 'Entre ton e-mail et un mot de passe de 8 caractères minimum.');
    if (authMode === 'signup' && !/^[a-zA-Z0-9_]{3,20}$/.test(username)) return Alert.alert('Nom invalide', 'Le nom doit contenir 3 à 20 lettres, chiffres ou tirets bas.');
    const result = authMode === 'signup'
      ? await supabase.auth.signUp({ email: email.trim(), password, options: { data: { username: username.toLowerCase(), display_name: displayName.trim() || username } } })
      : await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (result.error) Alert.alert('Connexion', result.error.message);
    else if (authMode === 'signup' && !result.data.session) Alert.alert('Vérifie ton e-mail', 'Un e-mail de confirmation a été envoyé avant la première connexion.');
  }

  async function publish() {
    if (!video || !session?.user) return Alert.alert('Vidéo manquante', 'Choisis une vidéo avant de publier.');
    if (video.duration && video.duration > 60_000) return Alert.alert('Vidéo trop longue', 'Pour cette première version, choisis une vidéo de 60 secondes maximum.');
    try {
      const response = await fetch(video.uri);
      const blob = await response.blob();
      const ext = (video.fileName?.split('.').pop() || 'mp4').toLowerCase().replace(/[^a-z0-9]/g, '') || 'mp4';
      const path = `${session.user.id}/${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from('videos').upload(path, blob, { contentType: video.mimeType || 'video/mp4', upsert: false });
      if (uploadError) throw uploadError;
      const { data: publicUrl } = supabase.storage.from('videos').getPublicUrl(path);
      const { error } = await supabase.from('videos').insert({
        user_id: session.user.id, caption: caption.trim().slice(0, 180),
        video_url: publicUrl.publicUrl, storage_path: path, status: 'pending'
      });
      if (error) throw error;
      setVideo(null); setCaption('');
      Alert.alert('Vidéo envoyée', 'Ta vidéo est enregistrée et attend une vérification avant sa publication.');
      setTab('profile');
    } catch (e:any) { Alert.alert('Publication impossible', e.message || 'Réessaie plus tard.'); }
  }

  async function toggleLike(post:Post) {
    if (post.liked) {
      const { error } = await supabase.from('likes').delete().eq('video_id', post.id).eq('user_id', session.user.id);
      if (error) Alert.alert('Like', error.message);
    } else {
      const { error } = await supabase.from('likes').insert({ video_id: post.id, user_id: session.user.id });
      if (error && error.code !== '23505') Alert.alert('Like', error.message);
    }
    loadFeed();
  }

  async function openComments(post:Post) {
    setCommentPost(post);
    const { data, error } = await supabase.from('comments').select('id,body,created_at,profiles(username)').eq('video_id', post.id).order('created_at');
    if (error) Alert.alert('Commentaires', error.message); else setComments(data || []);
  }

  async function addComment() {
    if (!commentPost || !commentText.trim()) return;
    const { error } = await supabase.from('comments').insert({ video_id: commentPost.id, user_id: session.user.id, body: commentText.trim().slice(0, 500) });
    if (error) Alert.alert('Commentaire', error.message);
    else { setCommentText(''); openComments(commentPost); }
  }

  async function follow(post:Post) {
    const { data } = await supabase.from('follows').select('follower_id').eq('follower_id', session.user.id).eq('following_id', post.user_id).maybeSingle();
    if (data) await supabase.from('follows').delete().eq('follower_id', session.user.id).eq('following_id', post.user_id);
    else await supabase.from('follows').insert({ follower_id: session.user.id, following_id: post.user_id });
    loadFeed();
  }

  async function saveProfile() {
    if (!myProfile) return;
    const { error } = await supabase.from('profiles').update({ bio: editBio.slice(0, 160) }).eq('id', session.user.id);
    if (error) Alert.alert('Profil', error.message); else { loadAccount(); Alert.alert('Profil enregistré'); }
  }

  async function findChat() {
    const { data, error } = await supabase.from('profiles').select('id,username').eq('username', targetUsername.toLowerCase().trim()).maybeSingle();
    if (error || !data) return Alert.alert('Utilisateur introuvable', 'Vérifie son nom d’utilisateur.');
    setChatUser(data.id);
    await loadMessages(data.id);
  }

  async function loadMessages(otherId:string) {
    const { data, error } = await supabase.from('messages').select('*')
      .or(`and(sender_id.eq.${session.user.id},receiver_id.eq.${otherId}),and(sender_id.eq.${otherId},receiver_id.eq.${session.user.id})`)
      .order('created_at');
    if (error) Alert.alert('Messages', error.message); else setMessages(data || []);
  }

  async function sendMessage() {
    if (!chatUser || !chatText.trim()) return;
    const { error } = await supabase.from('messages').insert({ sender_id: session.user.id, receiver_id: chatUser, body: chatText.trim().slice(0, 1000) });
    if (error) Alert.alert('Message non envoyé', error.message);
    else { setChatText(''); loadMessages(chatUser); }
  }

  async function chooseVideo() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return Alert.alert('Autorisation', 'Autorise l’accès aux vidéos sélectionnées dans les paramètres du téléphone.');
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'], allowsEditing: false, quality: 0.8, videoMaxDuration: 60 });
    if (!result.canceled) setVideo(result.assets[0]);
  }

  if (!isConfigured) return <SafeAreaView style={s.center}><Text style={s.logo}>ABOUBACAR <Text style={{color:pink}}>TOK</Text></Text><Text style={s.whiteText}>Le projet est prêt, mais le serveur doit être configuré.</Text><Text style={s.help}>Ajoute l’URL et la clé publique Supabase dans le fichier .env, puis relance l’application. Consulte le README.</Text></SafeAreaView>;
  if (loading) return <View style={s.center}><ActivityIndicator color={pink}/></View>;

  if (!session) return (
    <SafeAreaView style={s.auth}>
      <ExpoStatusBar style="light"/>
      <Text style={s.logo}>ABOUBACAR <Text style={{color:pink}}>TOK</Text></Text>
      <Text style={s.subtitle}>Les vidéos courtes, ta communauté.</Text>
      <Text style={s.sectionTitle}>{authMode === 'signup' ? 'Créer un compte' : 'Se connecter'}</Text>
      {authMode === 'signup' && <>
        <TextInput style={s.input} placeholder="Nom d’utilisateur (ex. aboubacar)" placeholderTextColor={muted} value={username} onChangeText={setUsername} autoCapitalize="none"/>
        <TextInput style={s.input} placeholder="Nom affiché" placeholderTextColor={muted} value={displayName} onChangeText={setDisplayName}/>
      </>}
      <TextInput style={s.input} placeholder="Adresse e-mail" placeholderTextColor={muted} value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address"/>
      <TextInput style={s.input} placeholder="Mot de passe (8 caractères minimum)" placeholderTextColor={muted} value={password} onChangeText={setPassword} secureTextEntry/>
      <TouchableOpacity style={s.primary} onPress={authenticate}><Text style={s.primaryText}>{authMode === 'signup' ? 'Créer mon compte' : 'Connexion'}</Text></TouchableOpacity>
      <TouchableOpacity onPress={() => setAuthMode(authMode === 'signup' ? 'login' : 'signup')}><Text style={s.switch}>{authMode === 'signup' ? 'J’ai déjà un compte · Se connecter' : 'Nouveau ici ? Créer un compte'}</Text></TouchableOpacity>
      <Text style={s.help}>Respecte les autres membres. Ne publie pas d’informations personnelles, d’adresse ou de numéro de téléphone.</Text>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={s.app}>
      <ExpoStatusBar style="light"/>
      <View style={s.header}><Text style={s.logoSmall}>ABOUBACAR <Text style={{color:pink}}>TOK</Text></Text><TouchableOpacity onPress={() => supabase.auth.signOut()}><Text style={s.smallMuted}>Déconnexion</Text></TouchableOpacity></View>
      {tab === 'feed' && <View style={{flex:1}}>
        <View style={s.feedTabs}><Text style={s.whiteBold}>Pour toi</Text><Text style={s.smallMuted}> • Vidéos publiques</Text><TouchableOpacity onPress={loadFeed}><Text style={{color:pink}}>Actualiser</Text></TouchableOpacity></View>
        {posts.length ? <FlatList data={posts} keyExtractor={p=>p.id} renderItem={({item})=><VideoCard post={item} userId={session.user.id} onLike={toggleLike} onComment={openComments} onFollow={follow}/>} /> : <View style={s.center}><Text style={s.whiteBold}>Pas encore de vidéos</Text><Text style={s.help}>Les vidéos approuvées apparaîtront ici.</Text></View>}
      </View>}
      {tab === 'publish' && <ScrollView contentContainerStyle={s.page}>
        <Text style={s.sectionTitle}>Publier une vidéo</Text><Text style={s.help}>Choisis une vidéo de 60 secondes maximum. Les publications sont mises en attente de vérification.</Text>
        <TouchableOpacity style={s.uploadBox} onPress={chooseVideo}><Text style={{fontSize:36,color:pink}}>＋</Text><Text style={s.whiteBold}>{video ? video.fileName || 'Vidéo sélectionnée' : 'Choisir une vidéo'}</Text><Text style={s.smallMuted}>Depuis la galerie du téléphone</Text></TouchableOpacity>
        <TextInput style={[s.input,{height:90,textAlignVertical:'top'}]} multiline placeholder="Écris une légende…" placeholderTextColor={muted} value={caption} onChangeText={setCaption} maxLength={180}/>
        <TouchableOpacity style={s.primary} onPress={publish}><Text style={s.primaryText}>Envoyer pour vérification</Text></TouchableOpacity>
      </ScrollView>}
      {tab === 'profile' && <ScrollView contentContainerStyle={s.page}>
        <View style={s.profileCircle}><Text style={{fontSize:28,color:'white'}}>{(myProfile?.display_name || 'A')[0]?.toUpperCase()}</Text></View>
        <Text style={[s.sectionTitle,{textAlign:'center'}]}>{myProfile?.display_name || 'Mon profil'}</Text>
        <Text style={[s.smallMuted,{textAlign:'center'}]}>@{myProfile?.username || 'utilisateur'}</Text>
        <TextInput style={[s.input,{height:80,textAlignVertical:'top'}]} value={editBio} onChangeText={setEditBio} placeholder="Ta bio" placeholderTextColor={muted} maxLength={160} multiline/>
        <TouchableOpacity style={s.primary} onPress={saveProfile}><Text style={s.primaryText}>Enregistrer ma bio</Text></TouchableOpacity>
        <Text style={s.sectionTitle}>Mes vidéos</Text>
        {posts.filter(p=>p.user_id===session.user.id).map(p=><Text key={p.id} style={s.listItem}>▶  {p.caption || 'Sans légende'}</Text>)}
      </ScrollView>}
      {tab === 'messages' && <KeyboardAvoidingView style={s.page} behavior={Platform.OS==='ios'?'padding':undefined}>
        <Text style={s.sectionTitle}>Messagerie</Text>
        <Text style={s.help}>Les messages sont privés. Échange uniquement avec des personnes que tu connais et bloque/signale tout comportement gênant.</Text>
        <View style={s.row}><TextInput style={[s.input,{flex:1}]} placeholder="Nom d’utilisateur" placeholderTextColor={muted} value={targetUsername} onChangeText={setTargetUsername} autoCapitalize="none"/><TouchableOpacity style={s.primarySmall} onPress={findChat}><Text style={s.primaryText}>Ouvrir</Text></TouchableOpacity></View>
        <ScrollView style={{flex:1}}>{messages.map(m=><View key={m.id} style={[s.messageBubble,m.sender_id===session.user.id&&s.ownMessage]}><Text style={s.whiteText}>{m.body}</Text></View>)}</ScrollView>
        {chatUser ? <View style={s.row}><TextInput style={[s.input,{flex:1}]} value={chatText} onChangeText={setChatText} placeholder="Ton message…" placeholderTextColor={muted}/><TouchableOpacity style={s.primarySmall} onPress={sendMessage}><Text style={s.primaryText}>Envoyer</Text></TouchableOpacity></View> : null}
      </KeyboardAvoidingView>}
      {commentPost && <View style={s.modalShade}><View style={s.modal}><View style={s.row}><Text style={s.sectionTitle}>Commentaires</Text><TouchableOpacity onPress={()=>setCommentPost(null)}><Text style={s.whiteBold}>Fermer ✕</Text></TouchableOpacity></View><ScrollView style={{maxHeight:250}}>{comments.map(c=><Text key={c.id} style={s.listItem}>@{c.profiles?.username || 'membre'}  {c.body}</Text>)}</ScrollView><View style={s.row}><TextInput style={[s.input,{flex:1}]} value={commentText} onChangeText={setCommentText} placeholder="Ajouter un commentaire…" placeholderTextColor={muted}/><TouchableOpacity style={s.primarySmall} onPress={addComment}><Text style={s.primaryText}>Envoyer</Text></TouchableOpacity></View></View></View>}
      <View style={s.nav}>
        {(['feed','publish','messages','profile'] as const).map((t,i)=><TouchableOpacity key={t} style={s.navItem} onPress={()=>{setCommentPost(null);setTab(t);if(t==='feed')loadFeed();}}><Text style={[s.navIcon,tab===t&&{color:pink}]}>{['⌂','＋','✉','◉'][i]}</Text><Text style={[s.navLabel,tab===t&&{color:pink}]}>{['Accueil','Publier','Messages','Profil'][i]}</Text></TouchableOpacity>)}
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  app:{flex:1,backgroundColor:bg},auth:{flex:1,backgroundColor:bg,padding:24,justifyContent:'center'},
  center:{flex:1,backgroundColor:bg,alignItems:'center',justifyContent:'center',padding:24},
  header:{height:54,paddingHorizontal:16,flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderBottomWidth:1,borderColor:'#27272A'},
  logo:{fontSize:27,fontWeight:'900',color:'white',textAlign:'center',letterSpacing:-1},logoSmall:{fontSize:19,fontWeight:'900',color:'white'},
  subtitle:{color:muted,textAlign:'center',marginTop:8,marginBottom:35},sectionTitle:{fontSize:21,fontWeight:'800',color:'white',marginVertical:12},
  input:{backgroundColor:panel,borderWidth:1,borderColor:'#3F3F46',borderRadius:12,padding:13,color:'white',marginVertical:7},
  primary:{backgroundColor:pink,padding:15,borderRadius:12,alignItems:'center',marginVertical:10},primarySmall:{backgroundColor:pink,padding:12,borderRadius:10,justifyContent:'center'},
  primaryText:{color:'white',fontWeight:'800'},switch:{color:'white',textAlign:'center',marginTop:18},help:{color:muted,fontSize:12,lineHeight:19,marginVertical:10},
  whiteText:{color:'white',fontSize:14,lineHeight:21},whiteBold:{color:'white',fontWeight:'800'},smallMuted:{color:'#D4D4D8',fontSize:11,marginTop:5},
  feedTabs:{height:42,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8},
  videoCard:{height:530,backgroundColor:'#202027',marginBottom:2,position:'relative'},
  video:{width:'100%',height:'100%'},videoOverlay:{position:'absolute',left:14,right:10,bottom:20,flexDirection:'row',alignItems:'flex-end'},
  actions:{width:82,alignItems:'center',gap:15},action:{alignItems:'center',marginVertical:3},actionIcon:{fontSize:28,color:'white',fontWeight:'700'},actionLabel:{fontSize:10,color:'white',marginTop:2},
  page:{padding:18,paddingBottom:35},uploadBox:{height:180,borderWidth:1,borderStyle:'dashed',borderColor:'#71717A',borderRadius:16,alignItems:'center',justifyContent:'center',marginVertical:18,backgroundColor:panel},
  profileCircle:{width:82,height:82,borderRadius:41,backgroundColor:'#71334A',alignItems:'center',justifyContent:'center',alignSelf:'center',marginTop:18},
  listItem:{color:'white',backgroundColor:panel,padding:13,borderRadius:10,marginVertical:5},row:{flexDirection:'row',alignItems:'center',gap:8},
  messageBubble:{alignSelf:'flex-start',backgroundColor:panel,padding:12,borderRadius:14,marginVertical:5,maxWidth:'85%'},ownMessage:{alignSelf:'flex-end',backgroundColor:'#7F1D3A'},
  nav:{height:62,flexDirection:'row',justifyContent:'space-around',alignItems:'center',borderTopWidth:1,borderColor:'#27272A',backgroundColor:'#111113'},
  navItem:{alignItems:'center',flex:1},navIcon:{fontSize:23,color:'#A1A1AA'},navLabel:{fontSize:10,color:'#A1A1AA',marginTop:2},
  modalShade:{position:'absolute',top:0,bottom:0,left:0,right:0,backgroundColor:'#000B',justifyContent:'flex-end'},
  modal:{backgroundColor:'#202024',borderTopLeftRadius:20,borderTopRightRadius:20,padding:18,minHeight:300}
});
