# ABOUBACAR TOK — application Android (base réelle)

Cette archive contient une base de projet Expo / React Native connectable à Supabase.
Elle n'est pas encore un APK prêt à installer : il faut créer/configurer le backend,
installer les dépendances et lancer une compilation Android.

## Fonctions incluses dans le code

- Création de compte et connexion par e-mail / mot de passe
- Profil avec nom d'utilisateur et bio
- Fil des vidéos publiées
- Sélection et envoi d'une vidéo (limite initiale : 60 secondes)
- Likes, commentaires et abonnements
- Messagerie privée simple
- Signalement de vidéos
- Mise en attente des vidéos (`pending`) avant publication

## Prérequis

- Un ordinateur avec Node.js LTS et Git
- Un compte Expo
- Un projet Supabase
- Un appareil Android pour tester

## 1. Configurer Supabase

1. Crée un projet Supabase depuis le tableau de bord officiel.
2. Ouvre **SQL Editor**.
3. Copie tout le contenu de `supabase/schema.sql` et exécute-le.
4. Dans **Project Settings > API**, récupère l'URL du projet et la clé `publishable`.
5. Dans la racine du projet, copie `.env.example` vers `.env` et remplis les deux valeurs.
6. Dans Supabase Auth, configure la confirmation e-mail et les règles anti-abus. Pour une mise en service publique, garde la confirmation e-mail activée.

La clé `publishable` peut être dans l'application mobile. **Ne mets jamais `service_role`, un mot de passe de base de données ou une clé secrète dans l'application.**

## 2. Installer et lancer

Dans le dossier du projet :

```bash
npm install
npx expo install --fix
npx expo start
```

Installe Expo Go sur le téléphone pour le premier test, puis scanne le QR code affiché par Expo.
Pour tester sur Android avec un émulateur, utilise `npm run android`.

## 3. Générer un APK Android

Quand le projet fonctionne :

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```

Le profil `preview` dans `eas.json` demande un APK de test. EAS fournit le lien de l'APK lorsque la compilation se termine. Une publication sur Play Store demande ensuite un compte développeur et un AAB de production.

## 4. Points indispensables avant une vraie ouverture au public

Ce projet est un socle technique, pas encore un réseau social prêt pour le grand public.

- Ajouter un véritable processus de modération (équipe, tableau de bord, retrait rapide).
- Ajouter un système complet de blocage, de prévention du harcèlement et de traitement des signalements.
- Restreindre la messagerie selon les paramètres de confidentialité et les relations entre utilisateurs.
- Ajouter pagination, compression vidéo, limites de débit, quotas de stockage et protection anti-spam.
- Vérifier les politiques RLS et Storage avec des comptes de test distincts.
- Ajouter politique de confidentialité, conditions d'utilisation, suppression de compte et procédure de contact.
- Prévoir les règles adaptées à l'âge des utilisateurs et ne pas exposer d'informations personnelles ou de localisation.
- Faire réaliser un audit de sécurité et de protection des données avant tout lancement public.

## Limites de cette version

- Les vidéos envoyées restent en `pending`; elles ne s'affichent pas dans le fil avant validation par un modérateur.
- La messagerie ne fonctionne que si le destinataire suit l'expéditeur (relation réciproque à établir selon la règle SQL).
- Les notifications push, les lives, l'algorithme de recommandation, la recherche avancée et l'interface de modération ne sont pas encore inclus.
- Le code doit être testé avec le SDK Expo installé par `npx expo install --fix` avant compilation.

## Architecture

- `App.tsx` : interface mobile et actions
- `src/lib/supabase.ts` : connexion au backend
- `supabase/schema.sql` : tables, règles de sécurité et bucket de vidéos
- `app.json` : identité Android de l'application
- `eas.json` : profils de compilation APK/AAB
