-- ABOUBACAR TOK - schéma initial Supabase
-- À exécuter dans Supabase > SQL Editor. Relire les règles avant toute ouverture publique.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[a-zA-Z0-9_]{3,20}$'),
  display_name text not null default 'Membre',
  bio text not null default '' check (char_length(bio) <= 160),
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  caption text not null default '' check (char_length(caption) <= 180),
  video_url text not null,
  storage_path text not null,
  status text not null default 'pending' check (status in ('pending','published','removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (video_id,user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id,following_id),
  check (follower_id <> following_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now(),
  check (sender_id <> receiver_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('video','profile','comment','message')),
  target_id uuid not null,
  reason text not null default 'Contenu à examiner',
  status text not null default 'open' check (status in ('open','reviewed','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id,blocked_id),
  check (blocker_id <> blocked_id)
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare
  requested_username text;
begin
  requested_username := coalesce(new.raw_user_meta_data->>'username', 'membre_' || substr(new.id::text,1,8));
  insert into public.profiles(id, username, display_name)
  values (new.id, requested_username, coalesce(new.raw_user_meta_data->>'display_name', requested_username))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;
alter table public.blocks enable row level security;

-- Profiles: lecture aux membres connectés, chacun modifie uniquement son profil.
create policy "profiles read signed in" on public.profiles for select to authenticated using (true);
create policy "profile owner update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Vidéos publiées visibles aux membres connectés; propriétaire peut voir ses propres vidéos en attente.
create policy "published videos readable" on public.videos for select to authenticated
using (status = 'published' or user_id = auth.uid());
create policy "owner creates pending videos" on public.videos for insert to authenticated
with check (user_id = auth.uid() and status = 'pending');
create policy "owner deletes own videos" on public.videos for delete to authenticated using (user_id = auth.uid());

create policy "likes visible to signed in" on public.likes for select to authenticated using (true);
create policy "member likes as self" on public.likes for insert to authenticated with check (user_id = auth.uid());
create policy "member removes own like" on public.likes for delete to authenticated using (user_id = auth.uid());

create policy "comments readable to signed in" on public.comments for select to authenticated using (true);
create policy "member comments as self" on public.comments for insert to authenticated with check (user_id = auth.uid());
create policy "member deletes own comment" on public.comments for delete to authenticated using (user_id = auth.uid());

create policy "follows readable" on public.follows for select to authenticated using (true);
create policy "follow as self" on public.follows for insert to authenticated with check (follower_id = auth.uid());
create policy "unfollow as self" on public.follows for delete to authenticated using (follower_id = auth.uid());

-- Messagerie privée: uniquement l'expéditeur et le destinataire.
create policy "participants read messages" on public.messages for select to authenticated
using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "sender sends message" on public.messages for insert to authenticated
with check (sender_id = auth.uid() and exists (
  select 1 from public.follows f
  where f.follower_id = receiver_id and f.following_id = sender_id
));
create policy "sender deletes message" on public.messages for delete to authenticated using (sender_id = auth.uid());

create policy "user creates report" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "reporter reads own report" on public.reports for select to authenticated using (reporter_id = auth.uid());

create policy "blocks visible to blocker" on public.blocks for select to authenticated using (blocker_id = auth.uid());
create policy "member blocks as self" on public.blocks for insert to authenticated with check (blocker_id = auth.uid());
create policy "member unblocks as self" on public.blocks for delete to authenticated using (blocker_id = auth.uid());

-- Bucket public pour lecture des vidéos publiées. Les écritures sont limitées au dossier utilisateur.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('videos','videos',true,104857600,array['video/mp4','video/quicktime','video/webm','video/3gpp'])
on conflict (id) do nothing;

create policy "authenticated users upload into own folder" on storage.objects
for insert to authenticated with check (
  bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text
);
create policy "video bucket readable" on storage.objects
for select to authenticated using (bucket_id = 'videos');
create policy "owners delete own video objects" on storage.objects
for delete to authenticated using (
  bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text
);

-- IMPORTANT:
-- Les vidéos restent en statut pending. Un modérateur de confiance doit les examiner
-- puis les passer à published via un environnement administratif sécurisé.
-- Ne jamais donner la clé service_role à l'application mobile.
